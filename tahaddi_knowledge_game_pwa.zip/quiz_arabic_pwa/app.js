const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const categories = {
  football:{label:"كرة القدم",icon:"⚽",file:"data/football.json"},
  programming:{label:"البرمجة",icon:"💻",file:"data/programming.json"},
  math:{label:"الحساب",icon:"🧮",file:"data/math.json"},
  general:{label:"معلومات عامة",icon:"🧠",file:"data/general.json"}
};
let category="football", playerCount=2, players=[], questions=[], questionIndex=0, activePlayer=0;
let soundEnabled=true, speaking=false, speechQueue=[], gameLocked=false, selectedAnswer=null, deferredInstall=null;

function renderPlayerFields(){
  const box=$("#playerFields");
  box.innerHTML="";
  for(let i=0;i<playerCount;i++){
    const input=document.createElement("input");
    input.className="player-input";input.maxLength=18;input.placeholder=`اسم اللاعب ${i+1}`;input.value=players[i]?.name||`اللاعب ${i+1}`;
    input.setAttribute("aria-label",`اسم اللاعب ${i+1}`);
    box.appendChild(input);
  }
  $("#countValue").textContent=playerCount;
}
function getPlayers(){return $$(".player-input").map((el,i)=>({name:el.value.trim()||`اللاعب ${i+1}`,score:0}));}
$("#countMinus").onclick=()=>{if(playerCount>1){players=getPlayers();playerCount--;renderPlayerFields();}};
$("#countPlus").onclick=()=>{if(playerCount<4){players=getPlayers();playerCount++;renderPlayerFields();}};
renderPlayerFields();

$$(".category-card").forEach(btn=>btn.addEventListener("click",()=>{
  $$(".category-card").forEach(b=>b.classList.remove("selected"));
  btn.classList.add("selected");category=btn.dataset.category;
}));

function speak(text, done=()=>{}){
  if(!soundEnabled || !("speechSynthesis" in window)){done();return;}
  speechQueue.push({text,done});runSpeechQueue();
}
function runSpeechQueue(){
  if(speaking || !speechQueue.length)return;
  const item=speechQueue.shift();
  if(!soundEnabled){item.done();runSpeechQueue();return;}
  speaking=true;gameLocked=true;$("#speechStatus").textContent="🔊 جاري النطق...";
  const utterance=new SpeechSynthesisUtterance(item.text);
  utterance.lang="ar-EG";utterance.rate=.92;utterance.pitch=1;utterance.volume=1;
  utterance.onend=()=>finishSpeech(item);
  utterance.onerror=()=>finishSpeech(item);
  window.speechSynthesis.speak(utterance);
}
function finishSpeech(item){
  speaking=false;item.done();
  if(!speechQueue.length){gameLocked=false;$("#speechStatus").textContent="اختار إجابتك"; }
  runSpeechQueue();
}
function stopSpeech(){if("speechSynthesis" in window)window.speechSynthesis.cancel();speechQueue=[];speaking=false;gameLocked=false;}
$("#soundToggle").onclick=()=>{
  soundEnabled=!soundEnabled;$("#soundToggle").textContent=soundEnabled?"🔊":"🔇";
  if(!soundEnabled)stopSpeech();
};
function shuffle(arr){return [...arr].sort(()=>Math.random()-.5);}
async function startGame(){
  stopSpeech();players=getPlayers();
  try{
    const response=await fetch(categories[category].file);
    if(!response.ok)throw new Error("تعذر تحميل الأسئلة");
    const data=await response.json();
    const requested=Number($("#questionCount").value);
    questions=shuffle(data.questions).slice(0,Math.min(requested,data.questions.length));
    if(!questions.length)throw new Error("لا توجد أسئلة في هذه الفئة");
  }catch(e){alert("لم نتمكن من تحميل ملف الأسئلة. افتح الموقع عبر GitHub Pages أو خادم محلي، وليس file://");return;}
  players=players.map(p=>({...p,score:0}));questionIndex=0;activePlayer=0;
  $("#setupScreen").hidden=true;$("#resultScreen").hidden=true;$("#gameScreen").hidden=false;
  $("#totalQuestions").textContent=questions.length;showQuestion();
}
$("#startBtn").onclick=startGame;
$("#exitBtn").onclick=()=>{stopSpeech();$("#gameScreen").hidden=true;$("#setupScreen").hidden=false;};
function renderScores(){
  $("#scoreboard").innerHTML=players.map((p,i)=>`<div class="score-item ${i===activePlayer?"active":""}"><b>${escapeHTML(p.name)}</b><span>${p.score}</span></div>`).join("");
}
function escapeHTML(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function showQuestion(){
  if(questionIndex>=questions.length){finishGame();return;}
  selectedAnswer=null;gameLocked=true;
  const q=questions[questionIndex];
  $("#questionNumber").textContent=questionIndex+1;
  $("#progressBar").style.width=`${questionIndex/questions.length*100}%`;
  $("#categoryBadge").textContent=categories[category].icon+" "+categories[category].label;
  $("#questionText").textContent=q.question;
  $("#turnText").textContent=`دور ${players[activePlayer].name} — ركّز واختار الإجابة`;
  $("#feedback").textContent="";$("#feedback").className="feedback";
  renderScores();
  const letters=["أ","ب","ج","د"];
  $("#answersGrid").innerHTML=q.answers.map((answer,i)=>`<button class="answer-btn" data-index="${i}"><span class="answer-letter">${letters[i]}</span><span>${escapeHTML(answer)}</span></button>`).join("");
  $$(".answer-btn").forEach(btn=>btn.addEventListener("click",()=>chooseAnswer(Number(btn.dataset.index))));
  $("#speechStatus").textContent="استمع للسؤال...";
  speak(q.question,()=>{gameLocked=false;$("#speechStatus").textContent="اختار إجابتك";});
}
function chooseAnswer(index){
  if(gameLocked||selectedAnswer!==null)return;
  selectedAnswer=index;gameLocked=true;
  const q=questions[questionIndex], correct=index===q.correct;
  const buttons=$$(".answer-btn");
  buttons.forEach((b,i)=>{b.disabled=true;if(i===q.correct)b.classList.add("correct");if(i===index&&!correct)b.classList.add("wrong");});
  if(correct)players[activePlayer].score+=10;
  renderScores();
  $("#feedback").textContent=correct?"إجابة صحيحة! +١٠ نقاط 🎉":`مش هي دي! الإجابة الصحيحة: ${q.answers[q.correct]}`;
  $("#feedback").className="feedback "+(correct?"good":"bad");
  $("#speechStatus").textContent="استمع للإجابة...";
  // The answer is queued behind any speech already in progress.
  speak(`الإجابة ${q.answers[index]}. ${correct?"إجابة صحيحة، عشر نقاط!":`الإجابة الصحيحة هي ${q.answers[q.correct]}`}`,()=>{
    setTimeout(()=>{
      activePlayer=(activePlayer+1)%players.length;
      if(activePlayer===0)questionIndex++;
      showQuestion();
    },450);
  });
}
$("#repeatQuestionBtn").onclick=()=>{
  if(questionIndex<questions.length&&!speaking){gameLocked=true;speak(questions[questionIndex].question,()=>{gameLocked=false;});}
};
function finishGame(){
  stopSpeech();$("#gameScreen").hidden=true;$("#resultScreen").hidden=false;
  const sorted=[...players].sort((a,b)=>b.score-a.score),top=sorted[0],ties=sorted.filter(p=>p.score===top.score);
  if(ties.length>1){$("#resultTitle").textContent="تعادل رائع!";$("#winnerName").textContent=ties.map(p=>p.name).join(" و ");$("#winnerSubtitle").textContent=`كل واحد حصل على ${top.score} نقطة. أنتم أبطال!`;speak(`انتهت اللعبة. تعادل رائع بين ${ties.map(p=>p.name).join(" و ")}.`,()=>{});}
  else{$("#resultTitle").textContent="الفائز هو";$("#winnerName").textContent=top.name;$("#winnerSubtitle").textContent=`حقق ${top.score} نقطة من ${questions.length*10} نقطة ممكنة. تستاهل الفوز!`;speak(`انتهت اللعبة. الفائز هو ${top.name}. مبروك!`,()=>{});}
  $("#finalScores").innerHTML=sorted.map((p,i)=>`<div class="final-score-row"><b>${i===0?"🏆":`${i+1}.`} ${escapeHTML(p.name)}</b><strong>${p.score} نقطة</strong></div>`).join("");
  $("#progressBar").style.width="100%";
}
$("#replayBtn").onclick=startGame;
$("#changeBtn").onclick=()=>{stopSpeech();$("#resultScreen").hidden=true;$("#setupScreen").hidden=false;};

$("#installBtn").onclick=async()=>{
  if(!deferredInstall)return;
  deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;$("#installBtn").hidden=true;
};
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("#installBtn").hidden=false;});
window.addEventListener("appinstalled",()=>{$("#installBtn").hidden=true;});
if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")){
  window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(console.warn));
}
